Buenas profe, le dejo las dependencias que tiene que instalar para correr la app. Es solo ts. ¡Abrazo!

### Pegar en consola
- npm install -D typescript ts-node @types/node

### Después de instalar 
- npm run dev 